//
//  CPBusinessControllerManager.h
//  lottery
//
//  Created by wayne on 2017/9/6.
//  Copyright © 2017年 施冬伟. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CPBusinessControllerManager : NSObject


#pragma mark- public
+(void)pushToWithdrawControllerOnViewController:(UIViewController *)onViewController;

@end
