//
//  CPLotteryResultMainCellStyle2.h
//  lottery
//
//  Created by wayne on 2017/7/18.
//  Copyright © 2017年 施冬伟. All rights reserved.
//

#import "CPLotteryResultMainCellStyle0.h"

@interface CPLotteryResultMainCellStyle2 : CPLotteryResultMainCellStyle0

@end
