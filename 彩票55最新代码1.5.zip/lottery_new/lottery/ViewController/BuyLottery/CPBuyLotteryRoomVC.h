//
//  CPBuyLotteryRoomVC.h
//  lottery
//
//  Created by wayne on 2017/9/20.
//  Copyright © 2017年 施冬伟. All rights reserved.
//

#import "CPBaseViewController.h"

@interface CPBuyLotteryRoomVC : CPBaseViewController

@property(nonatomic,strong)NSArray *roomList;
@property(nonatomic,copy)NSString *lotteryName;
@property(nonatomic,copy)NSString *gid;

@end
