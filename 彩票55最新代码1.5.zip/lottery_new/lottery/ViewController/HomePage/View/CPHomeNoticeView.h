//
//  CPHomeNoticeView.h
//  lottery
//
//  Created by wayne on 2017/10/17.
//  Copyright © 2017年 施冬伟. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CPHomeNoticeView : UIView

+(void)showWithPopInfo:(NSDictionary *)popInfo;

@end
