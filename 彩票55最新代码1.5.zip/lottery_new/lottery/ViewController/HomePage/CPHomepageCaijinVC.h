//
//  CPHomepageCaijinVC.h
//  lottery
//
//  Created by 施小伟 on 2018/1/2.
//  Copyright © 2018年 施冬伟. All rights reserved.
//

#import "CPBaseViewController.h"
#import "CPHomepageActivityCaijin.h"
@interface CPHomepageCaijinVC : CPBaseViewController

@property(nonatomic,retain)CPHomepageActivityCaijin *caijin;

@end
