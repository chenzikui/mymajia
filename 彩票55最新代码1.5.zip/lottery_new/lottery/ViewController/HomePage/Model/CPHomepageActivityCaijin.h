//
//  CPHomepageActivityCaijin.h
//  lottery
//
//  Created by 施小伟 on 2018/1/2.
//  Copyright © 2018年 施冬伟. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CPHomepageActivityCaijin : NSObject

@property(nonatomic,copy)NSString *content;
@property(nonatomic,copy)NSString *image;
@property(nonatomic,copy)NSString *phone;
@property(nonatomic,copy)NSString *title;


@end
