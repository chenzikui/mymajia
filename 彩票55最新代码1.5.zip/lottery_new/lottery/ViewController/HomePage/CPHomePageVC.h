//
//  CPHomePageVC.h
//  lottery
//
//  Created by wayne on 17/1/19.
//  Copyright © 2017年 施冬伟. All rights reserved.
// 128 42 

#import <UIKit/UIKit.h>
#import "CPBaseViewController.h"

@interface CPHomePageVC : CPBaseViewController

@end
