//
//  CPRechargeNetBankCell.h
//  lottery
//
//  Created by wayne on 2017/9/10.
//  Copyright © 2017年 施冬伟. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CPRechargeNetBankCell : UITableViewCell

-(void)addBankName:(NSString *)bankName
          selected:(BOOL)selected;

@end
