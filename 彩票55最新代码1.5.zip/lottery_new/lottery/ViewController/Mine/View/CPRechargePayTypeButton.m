//
//  CPRechargePayTypeButton.m
//  lottery
//
//  Created by 施小伟 on 2017/11/17.
//  Copyright © 2017年 施冬伟. All rights reserved.
//

#import "CPRechargePayTypeButton.h"

@implementation CPRechargePayTypeButton

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
