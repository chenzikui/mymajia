//
//  CPRechargePayTypeButton.h
//  lottery
//
//  Created by 施小伟 on 2017/11/17.
//  Copyright © 2017年 施冬伟. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CPRechargePayTypeButton : UIButton

@property(nonatomic,copy)NSString *payCode;

@end
