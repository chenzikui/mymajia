//
//  CPSignRecordVC.h
//  lottery
//
//  Created by wayne on 2017/8/26.
//  Copyright © 2017年 施冬伟. All rights reserved.
//

#import "CPBaseViewController.h"

@interface CPMyRecommendRecordVC : CPBaseViewController

@end
