//
//  CPBetRecordVC.h
//  lottery
//
//  Created by wayne on 2017/8/30.
//  Copyright © 2017年 施冬伟. All rights reserved.
//

#import "CPBaseViewController.h"

@interface CPAccountRecordVC : CPBaseViewController

@end
