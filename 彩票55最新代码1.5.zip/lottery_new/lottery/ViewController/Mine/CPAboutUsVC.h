//
//  CPAboutUsVC.h
//  lottery
//
//  Created by wayne on 2017/9/1.
//  Copyright © 2017年 施冬伟. All rights reserved.
//

#import "CPBaseViewController.h"

@interface CPAboutUsVC : CPBaseViewController

@property(nonatomic,copy)NSString *message;

@end
