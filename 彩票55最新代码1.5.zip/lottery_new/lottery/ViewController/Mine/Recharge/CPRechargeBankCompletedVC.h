//
//  CPRechargeBankCompletedVC.h
//  lottery
//
//  Created by wayne on 2017/9/11.
//  Copyright © 2017年 施冬伟. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CPRechargeBankCompletedVC : UIViewController

@property(nonatomic,copy)NSString *rechargeMoney;

@end
