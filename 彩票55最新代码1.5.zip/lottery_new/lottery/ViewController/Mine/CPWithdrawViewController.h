//
//  CPWithdrawViewController.h
//  lottery
//
//  Created by wayne on 2017/9/7.
//  Copyright © 2017年 施冬伟. All rights reserved.
//

#import "CPBaseViewController.h"

@interface CPWithdrawViewController : CPBaseViewController

@property(nonatomic,retain)NSDictionary *withdrawInfo;

@end
