//
//  CPBankCardInfoVC.h
//  lottery
//
//  Created by wayne on 2017/9/1.
//  Copyright © 2017年 施冬伟. All rights reserved.
//

#import "CPBaseViewController.h"

@interface CPBankCardInfoVC : CPBaseViewController

@property(nonatomic,retain)NSDictionary *bankInfo;

@end
