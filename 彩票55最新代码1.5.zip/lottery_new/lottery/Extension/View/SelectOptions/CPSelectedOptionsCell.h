//
//  DDChooseShopSizeCell.h
//  dada
//
//  Created by wayne on 16/1/12.
//  Copyright © 2016年 wayne. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface CPSelectedOptionsCell : UITableViewCell

-(void)addContentText:(NSString *)text
           isShowLine:(BOOL)showLine
            isSeleted:(BOOL)isSelected;
@end
