//
//  CPLocalCodeLabel.h
//  lottery
//
//  Created by wayne on 2017/8/21.
//  Copyright © 2017年 施冬伟. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CPLocalCodeLabel : UILabel

@end
